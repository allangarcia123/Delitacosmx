DELITACOSMX-APP — PAQUETE PWA

Sube TODOS los archivos y carpetas de este paquete a la raíz del repositorio GitHub Pages, conservando las rutas:
- index.html
- manifest.webmanifest
- sw.js
- icons/

Luego espera a que GitHub Pages termine de publicar y abre la URL HTTPS de la app. En Android, usa Chrome actualizado y toca “Instalar DELITACOSMX-App”. Si no aparece el aviso, usa el menú ⋮ > “Instalar aplicación” o “Añadir a pantalla principal”.

Importante: ninguna web puede garantizar instalación en absolutamente todos los teléfonos Android. La disponibilidad depende de la versión del sistema, el navegador y sus políticas. Esta actualización añade los componentes estándar de PWA y una guía alternativa para navegadores sin aviso de instalación. La app sigue necesitando internet para funciones que usan Firebase y WhatsApp.
